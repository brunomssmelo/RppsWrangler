.onAttach <- function(libname, pkgname) {
    stop_logging()
}
